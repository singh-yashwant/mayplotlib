def print1():
    print("code for first program")

def print2():
    print("code for second program")
